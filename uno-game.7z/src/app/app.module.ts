import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ScoreInputComponent } from './components/score-input/score-input.component';
import { AddPlayerComponent } from './components/add-player/add-player.component';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { GameDashboardComponent } from './components/game-dashboard/game-dashboard.component';

const routes: Routes = [
  {path: 'dashboard', component: GameDashboardComponent},
  {path: 'players', component: AddPlayerComponent},
  {path: 'score', component: ScoreInputComponent},
  {path: '',redirectTo:'/dashboard',pathMatch:'full'},
  {path: '**',redirectTo:'/dashboard',pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    ScoreInputComponent,
    AddPlayerComponent,
    GameDashboardComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
