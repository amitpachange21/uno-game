import { Component } from '@angular/core';
import { Player } from 'src/app/common/player';
import { PlayerService } from 'src/app/services/player.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-player',
  templateUrl: './add-player.component.html',
  styleUrls: ['./add-player.component.css']
})
export class AddPlayerComponent {

  players: Player[] = [];
  message: string = "";

  //inject player service in constructor
  constructor(private playerService: PlayerService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(()=> {
      this.getAllPlayers()
    });
  }

  addPlayer(name: string, email: string) {
    console.log(`name is ${name} email is ${email}`);

    //call add method in servie
    this.playerService.addPlayer(name, email).subscribe(
      data => {
        this.message = data.message;
        this.getAllPlayers()
      }
    );
    
  }

  getAllPlayers() {
    console.log('get players')
    this.playerService.getAllPlayers().subscribe(
      data => {
        console.log(data)
        this.players = data;
      }
    )
  }

  
}
