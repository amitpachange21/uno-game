import { Component } from '@angular/core';

@Component({
  selector: 'app-score-input',
  templateUrl: './score-input.component.html',
  styleUrls: ['./score-input.component.css']
})
export class ScoreInputComponent {


  
  
  Geeks() {
      var input = document.getElementsByName('array[]');
      console.log(input)


      // document.getElementById("par").innerHTML = k;
      // document.getElementById("po").innerHTML = "Output";
  }
}
