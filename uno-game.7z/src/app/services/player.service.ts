import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Player } from '../common/player';
import { map, Observable, pipe } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  private baseUrl = 'https://prajwalhallale.com/api/player';
  
  constructor(private httpClient: HttpClient) { }

  addPlayer(name: string, email: string): Observable<GetResposePlayer> {
    
    const addPlayerUrl = `${this.baseUrl}/add/`;
    let params = new HttpParams();
    params = params.append("name", name);
    params = params.append("email", email);

    return this.httpClient.get<GetResposePlayer>(addPlayerUrl, {params: params})
  }

  getAllPlayers(): Observable<Player[]> {
    
    const allPlayerUrl = `${this.baseUrl}/all`;

    return this.httpClient.get<GetResposePlayer>(allPlayerUrl).pipe(
      map(response => response.data)
    )
  }

}

interface GetResposePlayer {
    status: string,
    message: string,
    data: Player[];
  
}
